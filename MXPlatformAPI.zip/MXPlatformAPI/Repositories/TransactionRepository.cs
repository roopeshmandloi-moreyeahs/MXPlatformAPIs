﻿using Microsoft.AspNetCore.Mvc;
using MXPlatformAPI.Helper;
using MXPlatformAPI.Interfaces;
using MXPlatformAPI.Responses;
using Newtonsoft.Json;
using RestSharp;
using System.Security.Policy;
using System.Text.Json;
using JsonSerializer = System.Text.Json.JsonSerializer;
using Transaction = MXPlatformAPI.Responses.ResponseNew.Transaction;

namespace MXPlatformAPI.Repositories
{
    public class TransactionRepository : ITransactionRepository
    {
        /// <summary>
        /// ListTransactionData
        /// </summary>
        /// <param name="userGuid"></param>
        /// <param name="accountGuid"></param>
        /// <param name="baseUrl"></param>
        /// <param name="basicAuth"></param>
        /// <returns>List of Transaction Data</returns>
        public Task<ResponseMessage> ListTransactionData(string userGuid, string accountGuid, string baseUrl, string basicAuth)
        {
            ResponseMessage _response = new();
            Data dataItem = new();
            HeaderHelperClass header = new();
            try
            {

                var options = new RestClientOptions(baseUrl + @"/users/" + userGuid + @"/accounts/" + accountGuid + @"/transactions")
                {
                    MaxTimeout = -1,
                };
                var client = new RestClient(options);

                var request = header.Addheader("Get", basicAuth); /// Calling header helper class

                RestResponse res = client.Execute(request);

                if (res.IsSuccessStatusCode)
                {
                    if (res.Content != null)
                    {
                        _response.Status = true;
                        _response.Message = "Transaction Data found.";
                        dataItem.JsonData = dataItem.JsonData = JsonSerializer.Deserialize<dynamic>(res.Content, new JsonSerializerOptions { PropertyNameCaseInsensitive = true });
                    }
                    else
                    {
                        _response.Status = false;
                        _response.Message = "Transaction Data not found!";
                    }
                    _response.Data = dataItem;
                }
                else
                {
                    _response.Status = false;
                }
            }
            catch (Exception ex)
            {
                _response.Message = ex.Message;
            }
            return Task.FromResult(_response);
        }

        /// <summary>
        /// ListTransactionDataByMember
        /// </summary>
        /// <param name="userGuid"></param>
        /// <param name="memberGuid"></param>
        /// <param name="baseUrl"></param>
        /// <param name="basicAuth"></param>
        /// <returns>List of Transaction Data</returns>
        public Task<ResponseMessage> ListTransactionDataByMember(string userGuid, string memberGuid, string baseUrl, string basicAuth)
        {
            ResponseMessage _response = new();
            Data dataItem = new();
            HeaderHelperClass header = new();
            try
            {

                var options = new RestClientOptions(baseUrl + @"/users/" + userGuid + @"/members/" + memberGuid + @"/transactions")
                {
                    MaxTimeout = -1,
                };
                var client = new RestClient(options);

                var request = header.Addheader("Get", basicAuth); /// Calling header helper class

                RestResponse res = client.Execute(request);

                if (res.IsSuccessStatusCode)
                {
                    if (res.Content != null)
                    {
                        _response.Status = true;
                        _response.Message = "Transaction Data found.";
                        dataItem.JsonData = dataItem.JsonData = JsonSerializer.Deserialize<dynamic>(res.Content, new JsonSerializerOptions { PropertyNameCaseInsensitive = true });
                    }
                    else
                    {
                        _response.Status = false;
                        _response.Message = "Transaction Data not found!";
                    }
                    _response.Data = dataItem;
                }
                else
                {
                    _response.Status = false;
                }
            }
            catch (Exception ex)
            {
                _response.Message = ex.Message;
            }
            return Task.FromResult(_response);
        }

        /// <summary>
        /// ListTransactionDataByUserGuid
        /// </summary>
        /// <param name="userGuid"></param>
        /// <param name="baseUrl"></param>
        /// <param name="basicAuth"></param>
        /// <returns>List of Transaction Data</returns>
        public Task<ResponseMessage> ListTransactionDataByUserGuid(string userGuid, string baseUrl, string basicAuth)
        {
            ResponseMessage _response = new();
            ResponseNew _responseNew = new();
            Data dataItem = new();
            HeaderHelperClass header = new();
            try
            {

                var options = new RestClientOptions(baseUrl + @"/users/" + userGuid + @"/transactions")
                {
                    MaxTimeout = -1,
                };
                var client = new RestClient(options);

                var request = header.Addheader("Get", basicAuth); /// Calling header helper class

                RestResponse res = client.Execute(request);

                if (res.IsSuccessStatusCode)
                {
                    if (res.Content != null)                                                                                            
                    {

                        dataItem.JsonData = JsonSerializer.Deserialize<dynamic>(res.Content, new JsonSerializerOptions { PropertyNameCaseInsensitive = true });
                        //_response.Data.JsonData = UseDataAdaptor(res.Content);
                    }
                    else
                    {
                        _response.Status = false;
                        _response.Message = "Transaction Data not found!";
                    }
                   _response.Data = dataItem;
                }
                else
                {
                    _response.Status = false;
                }
            }
            catch (Exception ex)
            {
                _response.Message = ex.Message;
            }
            return Task.FromResult(_response);
        }

        /// <summary>
        /// Get Aggregated Transaction Data By User Guid
        /// </summary>
        /// <param name="userGuid"></param>
        /// <param name="baseUrl"></param>
        /// <param name="basicAuth"></param>
        /// <returns>List of Transaction Data</returns>



        public async Task<ResponseMessage> GetAggregatedDataByUserGuid(string userGuid, string baseUrl, string basicAuth)
        {
            ResponseMessage _response = new();
            List<ResponseNew.Institution> institution = new();
            List<ResponseNew.Account> accList = new();
            List<ResponseNew.Transaction> transList = new();
            DataNew dataItemNew = new();
            HelperDTO.Root account = new();
            HelperDTO.Transaction transaction = new();
            HeaderHelperClass header = new();
            ResponseNew.Root _root = new();
            try
            {

                var options = new RestClientOptions(baseUrl + @"/users/" + userGuid + "/accounts")
                {
                    MaxTimeout = -1,
                };
                var client = new RestClient(options);

                var request = header.Addheader("Get", basicAuth); /// Calling header helper class

                RestResponse res = client.Execute(request);
                #region
                if (res.IsSuccessStatusCode)
                {
                    if (res.Content != null)
                    {

                        account = JsonSerializer.Deserialize<HelperDTO.Root>(res.Content, new JsonSerializerOptions { PropertyNameCaseInsensitive = true });
                        var instituteData = account.Accounts.DistinctBy(d => new { d.InstitutionCode });
                        var instituteSelected = instituteData.Select(g => new
                        {
                            g.InstitutionCode
                            // Add more properties as needed...
                        });
                        foreach (var item in instituteSelected)
                        {

                            var acccountFiltered = account.Accounts.Where(x => x.InstitutionCode == item.InstitutionCode).ToList();
                            foreach (var acc in acccountFiltered)
                            {
                               
                                var optionTransaction = new RestClientOptions(baseUrl + @"/users/" + userGuid + "/accounts/" + acc.Guid + "/transactions")
                                {
                                    MaxTimeout = -1,
                                };
                                var clientNew = new RestClient(optionTransaction);

                                var requestNew = header.Addheader("Get", basicAuth); /// Calling header helper class

                                RestResponse resNew = clientNew.Execute(requestNew);
                                if (resNew.IsSuccessStatusCode)
                                {
                                    if (resNew.Content != null)
                                    {
                                        transaction = JsonSerializer.Deserialize<HelperDTO.Transaction>(res.Content, new JsonSerializerOptions { PropertyNameCaseInsensitive = true });


                                        transList.Add(new Transaction { ExternalTransactionId = transaction.Guid,Amount=transaction.Amount,Date=transaction.Date,Description=transaction.Description });
                                    
                                        //foreach(var trans in transaction)

                                        accList.Add(new ResponseNew.Account
                                        {
                                            AccountNumber = acc.AccountNumber,
                                            AccountType = acc.Type,
                                            CurrencyCode = acc.CurrencyCode,
                                            ExternalAccountId = acc.Guid,
                                            DataSourceId = acc.Id,
                                            AvailableBalance = acc.AvailableBalance.ToString(),
                                            CurrentBalance = acc.Balance.ToString()
                                        });
                                    }
                                }
                            }
                            institution.Add(new ResponseNew.Institution { Name = item.InstitutionCode, Accounts = accList });
                        } 
                    }
                    else
                    {
                        _response.Status = false;
                        _response.Message = "Transaction Data not found!";
                    }

                }
                else
                {
                    _response.Status = false;
                    _response.Message = "Transaction Data not found!";
                }
                _root.Institutions = institution;
                dataItemNew.JsonDataNew = _root;
                _response.dataNew = dataItemNew;
                _response.Status = true;
                _response.Message = "Transaction data found!";
                #endregion
            }
            catch (Exception ex)
            {
                _response.Message = ex.Message;
            }

            return await Task.FromResult(_response);
        }


        //private async Task<ResponseMessage> UseDataAdaptor(string jsonString)
        //{
        //    ResponseMessage _response = new ResponseMessage();
        //    Data data = new();
        //    RootObject root = JsonConvert.DeserializeObject<RootObject>(jsonString);
        //    List<ResponseNew.Account> acc = new();
        //    List<ResponseNew.Account> account = new();
        //    ResponseNew.Account account1 = new();
        //    List<Transaction> trans = new();
            
        //    foreach (var transaction in root.Transactions)
        //    {
        //        //Access and loop through the transactions
        //        acc.Add(new ResponseNew.Account
        //        {
        //            AccountNumber = transaction.AccountId,
        //            AccountType = transaction.Type,
        //            CurrencyCode = transaction.CurrencyCode,
        //            DataSourceId = transaction.Id,
        //            ExternalAccountId = transaction.AccountId,
        //            AvailableBalance = transaction.Amount.ToString()
        //        });
        //        account.Add(acc.FirstOrDefault());
        //        trans.Add(new Transaction
        //        {
        //            ExternalTransactionId = transaction.Guid,
        //            Amount = transaction.Amount,
        //            Date = transaction.Date,
        //            Description = transaction.Description
        //        });

        //        //acc.Add(new Account {AccountNumber = transaction.account_id,
        //        //AccountType = transaction.type,
        //        //CurrencyCode = transaction.currency_code,
        //        //DataSourceId = transaction.id,
        //        //ExternalAccountId = transaction.account_guid,
        //        //AvailableBalance = transaction.amount.ToString()});
        //        ////account.AccountNumber = transaction.account_id;
        //        ////account.AccountType = transaction.type;
        //        ////account.CurrencyCode = transaction.currency_code;
        //        ////account.DataSourceId = transaction.id;
        //        ////account.ExternalAccountId = transaction.account_guid;
        //        ////account.AvailableBalance = transaction.amount.ToString();

        //        //Add more properties as needed
        //    }

        //    account1.Transactions = trans;
        //    Console.WriteLine(account);
        //    data.JsonData = account;
        //    _response.Data = data;
        //    return _response;
        //}
       
        /// <summary>
        /// ReadTransactionDataByTransactionGuid
        /// </summary>
        /// <param name="userGuid"></param>
        /// <param name="transactionGuid"></param>
        /// <param name="baseUrl"></param>
        /// <param name="basicAuth"></param>
        /// <returns>Transaction Data detail</returns>
        public Task<ResponseMessage> ReadTransactionDataByTransactionGuid(string userGuid, string transactionGuid, string baseUrl, string basicAuth)
        {
            ResponseMessage _response = new();
            Data dataItem = new();
            HeaderHelperClass header = new();
            try
            {

                var options = new RestClientOptions(baseUrl + @"/users/" + userGuid + @"/transactions/" + transactionGuid)
                {
                    MaxTimeout = -1,
                };
                var client = new RestClient(options);

                var request = header.Addheader("Get", basicAuth); /// Calling header helper class

                RestResponse res = client.Execute(request);

                if (res.IsSuccessStatusCode)
                {
                    if (res.Content != null)
                    {
                        _response.Status = true;
                        _response.Message = "Transaction Detail found.";
                        dataItem.JsonData = JsonSerializer.Deserialize<dynamic>(res.Content, new JsonSerializerOptions { PropertyNameCaseInsensitive = true });
                    }
                    else
                    {
                        _response.Status = false;
                        _response.Message = "Transaction Detail not found!";
                    }
                    _response.Data = dataItem;
                }
                else
                {
                    _response.Status = false;
                }
            }
            catch (Exception ex)
            {
                _response.Message = ex.Message;
            }
            return Task.FromResult(_response);
        }
    }
}
